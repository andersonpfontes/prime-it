
import apiClient from './http'

const login = (credentials) => {
  return apiClient.post('auth/login', credentials)
}

const logout = () => {
  // Implementar logout se necessário
}

const AuthService = {
  login,
  logout,
}

export default AuthService
