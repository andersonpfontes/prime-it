<template>
  <div class="rounded-2xl py-12 px-6 lg:px-12 text-center">
    <slot />
  </div>
</template>
